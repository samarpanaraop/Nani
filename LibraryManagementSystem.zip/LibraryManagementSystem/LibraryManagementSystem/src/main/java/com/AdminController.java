package com;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {
	
	AdminDAO aao= new AdminDAO();
	
	@RequestMapping("/adminlogin")
	
	public ModelAndView AdminUser(HttpServletRequest req, HttpServletResponse res) {
		String uname=req.getParameter("admin_name");
		String pass= req.getParameter("admin_password");
		String result1= null;
	
		result1 = aao.Validate1(uname,pass);
	
		ModelAndView mv= new ModelAndView();
		if(result1!=null) {
		mv.setViewName("Admin_welcom.jsp");
		mv.addObject("name",uname);
	}
	else {
		mv.setViewName("Registration1.jsp");
	}
	return mv;

}
	@RequestMapping("/adminregister")
	public ModelAndView AdminRegistration(HttpServletRequest req,HttpServletResponse res) {
		
		
		String userName=req.getParameter("userName");
		String passWord=req.getParameter("passWord");
		
		String result1=null;
		result1=aao.AdminRegistration(userName,passWord);
		
		ModelAndView mv= new ModelAndView();
		if(result1!=null) {
			mv.setViewName("Home.jsp");
			mv.addObject("name",userName);
		}else {
		    mv.setViewName("Registration1.jsp");	
		}
		
		return mv;
	}
	
	
	
	@RequestMapping("/insertbook")
	public ModelAndView insertBook(HttpServletRequest req,HttpServletResponse res) {
		
		
		String bname=req.getParameter("bname");
		String qty=req.getParameter("qty");
		String price=req.getParameter("price");
		String author = req.getParameter("author");
		
		String result1=null;
		result1=aao.InsertBook(bname,qty,price,author);
		
		ModelAndView mv= new ModelAndView();
		
		
		return mv;
	}


@RequestMapping("/deletebook")
public ModelAndView deleteBook(HttpServletRequest req,HttpServletResponse res) {
	
	
	String qty=req.getParameter("b");
	
	
	String result1=null;
	result1=aao.deleteBook(qty);
	
	ModelAndView mv= new ModelAndView();
	
	
	return mv;
}
}